Based on the Surge tuning library, revision e8aab5b, with small modifications
https://github.com/surge-synthesizer/tuning-library
